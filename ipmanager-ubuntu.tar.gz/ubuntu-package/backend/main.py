"""
FastAPI Backend for IP Manager
Scans network ranges using nmap on Ubuntu
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, validator
from typing import List, Optional
import nmap
import asyncio
from datetime import datetime
import json
import os

app = FastAPI(title="IP Manager API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for network access
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SCAN_RESULTS_FILE = "/data/scan_results.json"

class ScanRequest(BaseModel):
    subnet: str
    start_ip: int = 0
    end_ip: int = 255
    
    @validator("start_ip", "end_ip")
    def validate_ip_range(cls, v):
        if not 0 <= v <= 255:
            raise ValueError("IP must be 0-255")
        return v
    
    @validator("subnet")
    def validate_subnet(cls, v):
        parts = v.split(".")
        if len(parts) != 3:
            raise ValueError("Subnet must be x.x.x")
        return v

class IPStatus(BaseModel):
    ip: str
    status: str
    hostname: Optional[str] = None
    mac_address: Optional[str] = None
    vendor: Optional[str] = None
    open_ports: List[int] = []
    last_scanned: str

class ScanResponse(BaseModel):
    subnet: str
    total_ips: int
    active_ips: int
    inactive_ips: int
    scan_time: float
    results: List[IPStatus]

def save_scan_results(results: dict):
    os.makedirs(os.path.dirname(SCAN_RESULTS_FILE), exist_ok=True)
    with open(SCAN_RESULTS_FILE, "w") as f:
        json.dump(results, f, indent=2)

def load_scan_results() -> dict:
    if os.path.exists(SCAN_RESULTS_FILE):
        with open(SCAN_RESULTS_FILE, "r") as f:
            return json.load(f)
    return {}

async def scan_ip_range(subnet: str, start_ip: int, end_ip: int) -> List[IPStatus]:
    results = []
    ip_range = f"{subnet}.{start_ip}-{end_ip}"
    
    print(f"\nScanning {ip_range} with nmap...")
    
    try:
        nm = nmap.PortScanner()
        nm.scan(hosts=ip_range, arguments='-sn -n -T4')
        
        print(f"Nmap found {len(nm.all_hosts())} responding hosts")
        
        for last_octet in range(start_ip, end_ip + 1):
            ip = f"{subnet}.{last_octet}"
            
            if ip in nm.all_hosts() and nm[ip].state() == "up":
                host_info = nm[ip]
                
                hostname = None
                if 'hostnames' in host_info and host_info['hostnames']:
                    hostname = host_info['hostnames'][0].get('name')
                
                mac_address = None
                vendor = None
                if 'addresses' in host_info:
                    mac_address = host_info['addresses'].get('mac')
                    if mac_address and 'vendor' in host_info:
                        vendor = host_info['vendor'].get(mac_address)
                
                results.append(IPStatus(
                    ip=ip,
                    status="up",
                    hostname=hostname,
                    mac_address=mac_address,
                    vendor=vendor,
                    open_ports=[],
                    last_scanned=datetime.now().isoformat()
                ))
                print(f"  UP: {ip}" + (f" ({vendor})" if vendor else ""))
            else:
                results.append(IPStatus(
                    ip=ip,
                    status="down",
                    last_scanned=datetime.now().isoformat()
                ))
    
    except Exception as e:
        print(f"Scan error: {e}")
        for last_octet in range(start_ip, end_ip + 1):
            results.append(IPStatus(
                ip=f"{subnet}.{last_octet}",
                status="unknown",
                last_scanned=datetime.now().isoformat()
            ))
    
    return results

@app.get("/")
async def root():
    return {"message": "IP Manager API", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.post("/api/scan", response_model=ScanResponse)
async def scan_network(request: ScanRequest):
    scan_start = datetime.now()
    results = await scan_ip_range(request.subnet, request.start_ip, request.end_ip)
    
    active_count = sum(1 for r in results if r.status == "up")
    inactive_count = sum(1 for r in results if r.status == "down")
    
    response = ScanResponse(
        subnet=f"{request.subnet}.{request.start_ip}-{request.end_ip}",
        total_ips=len(results),
        active_ips=active_count,
        inactive_ips=inactive_count,
        scan_time=(datetime.now() - scan_start).total_seconds(),
        results=results
    )
    
    scan_data = load_scan_results()
    scan_key = f"{request.subnet}.{request.start_ip}-{request.end_ip}"
    scan_data[scan_key] = response.dict()
    save_scan_results(scan_data)
    
    return response
