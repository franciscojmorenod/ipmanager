import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [subnet, setSubnet] = useState('192.168.1');
  const [startIP, setStartIP] = useState(0);
  const [endIP, setEndIP] = useState(255);
  const [scanResults, setScanResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all'); // all, up, down

  const handleScan = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Call backend directly on port 8000
      const response = await axios.post('http://localhost:8000/api/scan', {
        subnet: subnet,
        start_ip: parseInt(startIP),
        end_ip: parseInt(endIP)
      });
      
      setScanResults(response.data);
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'Scan failed');
      console.error('Scan error:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredResults = scanResults?.results?.filter(ip => {
    if (filterStatus === 'all') return true;
    return ip.status === filterStatus;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'up':
        return '#4caf50';
      case 'down':
        return '#f44336';
      default:
        return '#9e9e9e';
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>🌐 Network IP Manager</h1>
        <p>Scan and monitor IP addresses on your network</p>
      </header>

      <div className="container">
        {/* Scan Controls */}
        <div className="scan-controls">
          <h2>Scan Configuration</h2>
          
          <div className="input-group">
            <label>Subnet (first 3 octets):</label>
            <input
              type="text"
              value={subnet}
              onChange={(e) => setSubnet(e.target.value)}
              placeholder="192.168.1"
              className="input-field"
            />
          </div>

          <div className="input-row">
            <div className="input-group">
              <label>Start IP:</label>
              <input
                type="number"
                value={startIP}
                onChange={(e) => setStartIP(e.target.value)}
                min="0"
                max="255"
                className="input-field"
              />
            </div>

            <div className="input-group">
              <label>End IP:</label>
              <input
                type="number"
                value={endIP}
                onChange={(e) => setEndIP(e.target.value)}
                min="0"
                max="255"
                className="input-field"
              />
            </div>
          </div>

          <div className="scan-info">
            <p>Will scan: <strong>{subnet}.{startIP}</strong> to <strong>{subnet}.{endIP}</strong></p>
            <p>Total IPs: <strong>{parseInt(endIP) - parseInt(startIP) + 1}</strong></p>
          </div>

          <button 
            onClick={handleScan} 
            disabled={loading}
            className="scan-button"
          >
            {loading ? '⏳ Scanning...' : '🔍 Start Scan'}
          </button>

          {error && (
            <div className="error-message">
              ❌ {error}
            </div>
          )}
        </div>

        {/* Results */}
        {scanResults && (
          <div className="results-section">
            <h2>Scan Results</h2>
            
            <div className="stats">
              <div className="stat-card">
                <div className="stat-value">{scanResults.total_ips}</div>
                <div className="stat-label">Total IPs</div>
              </div>
              <div className="stat-card active">
                <div className="stat-value">{scanResults.active_ips}</div>
                <div className="stat-label">Active</div>
              </div>
              <div className="stat-card inactive">
                <div className="stat-value">{scanResults.inactive_ips}</div>
                <div className="stat-label">Inactive</div>
              </div>
              <div className="stat-card">
                <div className="stat-value">{scanResults.scan_time.toFixed(2)}s</div>
                <div className="stat-label">Scan Time</div>
              </div>
            </div>

            <div className="filter-controls">
              <label>Filter:</label>
              <button 
                className={filterStatus === 'all' ? 'active' : ''}
                onClick={() => setFilterStatus('all')}
              >
                All ({scanResults.total_ips})
              </button>
              <button 
                className={filterStatus === 'up' ? 'active' : ''}
                onClick={() => setFilterStatus('up')}
              >
                Active ({scanResults.active_ips})
              </button>
              <button 
                className={filterStatus === 'down' ? 'active' : ''}
                onClick={() => setFilterStatus('down')}
              >
                Inactive ({scanResults.inactive_ips})
              </button>
            </div>

            <div className="ip-grid">
              {filteredResults?.map((ip) => (
                <div 
                  key={ip.ip} 
                  className="ip-card"
                  style={{ borderLeftColor: getStatusColor(ip.status) }}
                >
                  <div className="ip-header">
                    <span className="ip-address">{ip.ip}</span>
                    <span 
                      className={`status-badge ${ip.status}`}
                    >
                      {ip.status === 'up' ? '✓' : '✗'} {ip.status.toUpperCase()}
                    </span>
                  </div>
                  
                  {ip.hostname && (
                    <div className="ip-detail">
                      <span className="detail-label">Hostname:</span>
                      <span className="detail-value">{ip.hostname}</span>
                    </div>
                  )}
                  
                  {ip.mac_address && (
                    <div className="ip-detail">
                      <span className="detail-label">MAC:</span>
                      <span className="detail-value">{ip.mac_address}</span>
                    </div>
                  )}
                  
                  {ip.vendor && (
                    <div className="ip-detail">
                      <span className="detail-label">Vendor:</span>
                      <span className="detail-value">{ip.vendor}</span>
                    </div>
                  )}
                  
                  <div className="ip-detail">
                    <span className="detail-label">Last Scanned:</span>
                    <span className="detail-value">
                      {new Date(ip.last_scanned).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {!scanResults && !loading && (
          <div className="welcome-message">
            <h3>👋 Welcome to Network IP Manager</h3>
            <p>Enter your network subnet and IP range above, then click "Start Scan" to begin monitoring your network.</p>
            <div className="example">
              <strong>Example:</strong> For network 192.168.1.0/24, enter:
              <ul>
                <li>Subnet: <code>192.168.1</code></li>
                <li>Start IP: <code>0</code></li>
                <li>End IP: <code>255</code></li>
              </ul>
            </div>
          </div>
        )}
      </div>

      <footer className="App-footer">
        <p>Network IP Manager v1.0 | Powered by React + FastAPI + nmap</p>
      </footer>
    </div>
  );
}

export default App;
